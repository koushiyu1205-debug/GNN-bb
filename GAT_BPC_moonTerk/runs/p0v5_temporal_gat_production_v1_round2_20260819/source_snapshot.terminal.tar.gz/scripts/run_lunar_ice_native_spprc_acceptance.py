#!/usr/bin/env python3
"""Run parameterized native SPPRC acceptance without changing the B4.3 runner."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from lunar_ice_bpc.io.config import load_config
from lunar_ice_bpc.runners.native_spprc_acceptance import run_native_spprc_acceptance


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/benchmarks/native_spprc_acceptance.yaml")
    parser.add_argument("--scales", nargs="+", type=int, default=[5, 10, 20, 30, 50, 100])
    parser.add_argument(
        "--backend",
        choices=(
            "python_reference",
            "native_rcspp_inprocess",
            "native_rcspp_host",
            "native_rcspp_dssr_inprocess",
            "native_rcspp_dssr_host",
            "native_rcspp_dssr_v2_inprocess",
            "native_rcspp_dssr_v2_host",
            "native_rcspp_ng_dssr_v3_inprocess",
            "native_rcspp_ng_dssr_v3_host",
            "native_rcspp_bidirectional_midpoint_hybrid_v1",
        ),
    )
    parser.add_argument("--instance", action="append", default=[])
    parser.add_argument(
        "--instance-dir",
        action="append",
        default=[],
        help="Add every instance_*_logical_graph.json in this directory.",
    )
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--output-dir", default="runs/native_spprc_acceptance")
    parser.add_argument("--resume", action="store_true", default=False)
    parser.add_argument("--no-resume", action="store_false", dest="resume")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--effective-memory-cap-gb", type=float, default=0.0)
    parser.add_argument(
        "--route-opportunity-collection-only-root-pool",
        action="store_true",
        default=False,
        help=(
            "Collect the natural root-pool trajectory and stop before tree "
            "closure. The resulting rows are diagnostic and uncertified."
        ),
    )
    parser.add_argument(
        "--route-opportunity-collection-root-pool-time-cap-sec",
        type=float,
        default=0.0,
    )
    args = parser.parse_args()
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    instances = list(args.instance)
    for raw_directory in args.instance_dir:
        directory = Path(raw_directory)
        if not directory.is_absolute():
            directory = ROOT / directory
        instances.extend(
            str(path)
            for path in sorted(
                directory.glob("instance_*_logical_graph.json")
            )
        )
    summary = run_native_spprc_acceptance(
        project_root=ROOT,
        config=load_config(config_path),
        scales=tuple(args.scales),
        backend_override=args.backend,
        instances=tuple(instances),
        limit=args.limit,
        output_dir=args.output_dir,
        resume=args.resume,
        dry_run=args.dry_run,
        route_opportunity_collection_only_root_pool=bool(
            args.route_opportunity_collection_only_root_pool
        ),
        route_opportunity_collection_root_pool_time_cap_sec=float(
            args.route_opportunity_collection_root_pool_time_cap_sec
        ),
        effective_memory_cap_gb=float(args.effective_memory_cap_gb),
    )
    print(
        f"native SPPRC acceptance rows={len(summary['rows'])} "
        f"missing_scales={summary['missing_scales']} output={args.output_dir}"
    )
    return 0 if summary["all_available_runs_succeeded"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
