"""Native SPPRC backend tests."""
