"""Typed BPC certificate primitives."""

