"""Exact solver scaffolding."""

