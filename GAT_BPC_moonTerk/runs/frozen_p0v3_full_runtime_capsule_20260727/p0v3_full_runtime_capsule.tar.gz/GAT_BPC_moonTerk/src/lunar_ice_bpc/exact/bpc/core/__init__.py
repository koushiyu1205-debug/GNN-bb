"""Core typed BPC primitives."""

