"""Typed BPC pricing primitives."""

