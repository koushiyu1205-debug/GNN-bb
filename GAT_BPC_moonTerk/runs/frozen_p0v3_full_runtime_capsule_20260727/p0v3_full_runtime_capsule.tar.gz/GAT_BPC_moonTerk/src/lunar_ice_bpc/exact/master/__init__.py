"""Master-problem helpers."""

