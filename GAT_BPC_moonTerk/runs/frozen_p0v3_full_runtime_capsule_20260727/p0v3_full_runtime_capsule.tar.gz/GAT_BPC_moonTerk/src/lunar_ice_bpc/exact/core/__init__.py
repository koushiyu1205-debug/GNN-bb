"""Exact core data structures."""

